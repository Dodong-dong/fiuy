namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string letter;
            letter= Convert.ToString(textBox1.Text);
            


            if (letter == "R" || letter == "r")
                BackColor= Color.Red;
            else if (letter == "Y" || letter == "y")
                BackColor = Color.Yellow;
            else if (letter == "B" || letter == "b")
                BackColor = Color.Blue;
            else if (letter == "G" || letter == "g")
                BackColor = Color.Green;
            else
                BackColor = Color.Black;
        }
    }
}