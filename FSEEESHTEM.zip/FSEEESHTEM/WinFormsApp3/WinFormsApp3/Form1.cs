namespace WinFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double grade;
            grade = Convert.ToDouble(textBox1.Text);

            if (grade >= 97 && grade <= 100)
                label2.Text = ("1.00");
            if (grade >= 94 && grade <= 96)
                label2.Text = ("1.25");
            if (grade >= 91 && grade <= 93)
                label2.Text = ("1.50");
            if (grade >= 88 && grade <= 90)
                label2.Text = ("1.75");
            if (grade >= 85 && grade <= 87)
                label2.Text = ("2.00");
            if (grade >= 82 && grade <= 84)
                label2.Text = ("2.25");
            if (grade >= 79 && grade <= 81)
                label2.Text = ("2.50");
            if (grade >= 76 && grade <= 78)
                label2.Text = ("2.75");
            if (grade >= 75)
                label2.Text = ("3.00");
            if (grade <= 74)
                label2.Text = ("5.00");
            if (grade >= 101)
                label2.Text = ("out of range");
           

        }
    }
}