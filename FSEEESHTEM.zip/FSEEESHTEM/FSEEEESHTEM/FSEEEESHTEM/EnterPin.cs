﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FSEEEESHTEM
{
    public partial class EnterPin : Form


    {

        private void ClearTextBox()
        {
            textBox1.Clear();
        }
        public EnterPin()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int number = 2;
            textBox1.Text += number;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int number = 7;
            textBox1.Text += number;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int number = 3;
            textBox1.Text += number;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            if(textBox1.Text == "0924")
            {
                this.Hide();
                MainForm mainForm = new MainForm();
                mainForm.Show();
                MessageBox.Show("Log in Successfully!");
            }
            else
            {
                MessageBox.Show("Inncorrect PIN");
                textBox1.Text = "";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int number = 1;
            textBox1.Text += number;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int number = 4;
            textBox1.Text += number;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int number = 5;
            textBox1.Text += number;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            int number = 0;
            textBox1.Text += number;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int number = 9;
            textBox1.Text += number;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int number = 6;
            textBox1.Text += number;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int number = 8;
            textBox1.Text += number;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            ClearTextBox();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to exit", "Exit Message", MessageBoxButtons.YesNoCancel) == DialogResult);
            {
                MessageBox.Show("Thank You");
                Application.Exit();

            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            int number = 00;
            textBox1.Text += number;
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            vScrollBar1.Maximum = 110;
            vScrollBar1.Minimum=0;

            if (vScrollBar1.Value == 100)
            {

            }
        }
    }
}
