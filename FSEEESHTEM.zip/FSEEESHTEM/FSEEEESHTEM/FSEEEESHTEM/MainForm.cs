﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FSEEEESHTEM
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void ClearTextBox()
        {
            textBox1.Clear();
        }

        public Single rd, tb, tot;

        private void button6_Click(object sender, EventArgs e)
        {
            int number = 6;
            textBox1.Text += number;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                radioButton1.Text= "60.50";
                rd= Convert.ToSingle(radioButton1.Text);
                tb= Convert.ToSingle(textBox1.Text);
                tot = tb / rd;

                MessageBox.Show("Total: " + tot + "Liter", "Premium");
                
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int number = 1;
            textBox1.Text += number;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int number = 2;
            textBox1.Text += number;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int number = 3;
            textBox1.Text += number;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int number = 4;
            textBox1.Text += number;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int number = 5;
            textBox1.Text += number;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int number = 7;
            textBox1.Text += number;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int number = 8;
            textBox1.Text += number;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            ClearTextBox();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int number = 9;
            textBox1.Text += number;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            int number = 0;
            textBox1.Text += number;
        }
    }
}
