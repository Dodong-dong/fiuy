﻿//See https://aka.ms/new-console-template for more information


//Console.WriteLine("CARPIO,JANALYN C. ");
//Console.WriteLine("BSCS1B ");


//double a;
//Console.WriteLine("Enter Level: ");



//a = Convert.ToDouble(Console.ReadLine()); 
//switch (a)

//{
//    case 1:
//        Console.WriteLine("Freshmen");

//        break;

//    case 2:
//        Console.WriteLine("Sophomore");
//        break;

//    case 3:
//        Console.WriteLine("Junior");
//        break;

//    case 4:
//        Console.WriteLine("Senior");
//        break;

//    default:
//        Console.WriteLine("NONE OF THE ABOVE");
//        break;





using System;

Console.WriteLine("CARPIO,JANALYN C");
Console.WriteLine("BSCS 1B \n");


Console.Write("Item No: ");
int a = Convert.ToInt32(Console.ReadLine());
Console.Write("Item Name: ");
string d = Convert.ToString(Console.ReadLine());
Console.Write("Brand: ");
string h = Convert.ToString(Console.ReadLine());
Console.Write("Price:");
int k = Convert.ToInt32(Console.ReadLine());


Console.WriteLine("Add Item? Y/N");
if (Console.ReadLine().Equals("Y") || Console.ReadLine().Equals("N"))
{
    goto begin;
}
else
{

    Console.WriteLine("Item No: " + a);
    Console.WriteLine("Item Name: " + d);
    Console.WriteLine("Brand: " + h);
    Console.WriteLine("Price: " + k);
}
begin:
{
    Console.Write("Item No: ");
    int A = Convert.ToInt32(Console.ReadLine());
    Console.Write("Item Name: ");
    string D = Convert.ToString(Console.ReadLine()); ;
    Console.Write("Brand: ");
    string H = Convert.ToString(Console.ReadLine());
    Console.Write("Price:");
    int K = Convert.ToInt32(Console.ReadLine());

    Console.WriteLine("Add Item? Y/N");
    if (Console.ReadLine().Equals("Y") || Console.ReadLine().Equals("N"))
    {
        goto all;
    }
    else
    {
        Console.WriteLine("Item No: " + a + "," + A);
        Console.WriteLine("Item Name: " + d + " , " + D);
        Console.WriteLine("Brand: " + h + "," + H);
        Console.WriteLine("Price: " + k + "," + K);
    }
all:
    
        Console.Write("Item No: ");
        int b = Convert.ToInt32(Console.ReadLine());
        Console.Write("Item Name: ");
        string f = Convert.ToString(Console.ReadLine()); ;
        Console.Write("Brand: ");
        string i = Convert.ToString(Console.ReadLine());
        Console.Write("Price:");
        int l = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Add Item? Y/N");
        if (Console.ReadLine().Equals("Y") || Console.ReadLine().Equals("N"))
        {
        goto all;
        }
        else
        {
            Console.WriteLine("Item No: " + a + "," + A + "," + b);
            Console.WriteLine("Item Name: " + d + " , " + D + "," + f);
            Console.WriteLine("Brand: " + h + "," + H + "," + i);
            Console.WriteLine("Price: " + k + "," + K + "," + l);
        }
    }





    



