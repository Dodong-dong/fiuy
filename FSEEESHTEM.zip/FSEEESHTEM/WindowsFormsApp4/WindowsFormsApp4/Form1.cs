﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Double F, P1 = 0.5, P2 = 0.10, TF, TOTAL;
            TF = Convert.ToDouble(textBox1.Text);

            if (radioButton1.Checked)
            {
                TOTAL = TF - (TF * .1);
                textBox2.Text = TOTAL.ToString();
            }
            else if (radioButton2.Checked)
            {
                TOTAL = TF * 1.05;
                textBox2.Text = TOTAL.ToString();
            }
            else if (radioButton3.Checked)
            {
                TOTAL = TF * 1.1;
                textBox2.Text = TOTAL.ToString();
            }
           
        }
    }
}
