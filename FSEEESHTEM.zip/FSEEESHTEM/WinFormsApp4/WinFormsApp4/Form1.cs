namespace WinFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double grade;
            grade = Convert.ToDouble(textBox1.Text);

            if (grade >= 97 && grade <= 100)
                label2.Text = ("1.00");
            else if (grade >= 94 && grade <= 96)
                label2.Text = ("1.25");
            else if (grade >= 91 && grade <= 93)
                label2.Text = ("1.50");
            else if (grade >= 88 && grade <= 90)
                label2.Text = ("1.75");
            else if (grade >= 85 && grade <= 87)
                label2.Text = ("2.00");
            else if (grade >= 82 && grade <= 84)
                label2.Text = ("2.25");
            else if (grade >= 79 && grade <= 81)
                label2.Text = ("2.50");
            else if (grade >= 76 && grade <= 78)
                label2.Text = ("2.75");
            else if (grade >= 75)
                label2.Text = ("3.00");
            else if (grade >= 74 && grade <= 0)
                label2.Text = ("5.00");
            else if (grade >= 101)
            label2.Text = ("OUT OF RANGE");



        }
    }
}